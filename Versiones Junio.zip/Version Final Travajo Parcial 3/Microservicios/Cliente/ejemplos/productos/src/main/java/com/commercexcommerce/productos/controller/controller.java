package com.commercexcommerce.productos.controller;

import com.commercexcommerce.productos.clientes.ProductoCliente;
import com.commercexcommerce.productos.dto.ProductoDTO;
import com.commercexcommerce.productos.model.Cliente;
import com.commercexcommerce.productos.service.service;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/v1/clientes")
@Tag(name = "Cliente x Clientes", description = "Operaciones relacionadas con los clientes")
public class controller {

    @Autowired
    private service service;

    @Autowired
    private ProductoCliente productoCliente;

    @GetMapping
    public List<Cliente> obtenerClientes() {
        return service.obtenerClientes();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar Clientes", description = "Buscara por el listado de clientes registrados en Commerce x Commerce")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Cliente encontrado"),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado")})
    public Cliente buscarPorId(@PathVariable int id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    @Operation(summary = "Guardar Clientes")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Cliente registrado con exito"),
        @ApiResponse(responseCode = "400", description = "Cliente invalido")})
    public Cliente guardar(@RequestBody Cliente cliente) {
        return service.guardar(cliente);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar Clientes")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Datos de clientes actualizados de forma exitosa"),
        @ApiResponse(responseCode = "400", description = "Cliente no ha sido encontrado")})
    public Cliente actualizar(@PathVariable int id, @RequestBody Cliente cliente) {
        return service.actualizar(id, cliente);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar Cliente")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Cliente Eliminado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Cliente no Encontrado")})
    public boolean eliminar(@PathVariable int id) {
        return service.eliminar(id);
    }

    @GetMapping("/producto/{idProducto}")
    @Operation(summary = "Buscar Productos desde clientes")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Productos encontrados"),
        @ApiResponse(responseCode = "400", description = "Productos no encontrados")})
    public ProductoDTO consultarProductoDesdeCliente(@PathVariable int idProducto) {
        return productoCliente.buscarProductoPorId(idProducto);
    }
}