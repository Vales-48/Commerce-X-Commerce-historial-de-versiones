package com.commercexcommerce.productos.service;

import com.commercexcommerce.productos.model.Cliente;
import com.commercexcommerce.productos.repository.repository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ServiceTest {

    @Mock
    private repository repository;

    @InjectMocks
    private service service;

    private Cliente clienteEjemplo;

    @BeforeEach
    void setUp() {
        clienteEjemplo = new Cliente();
        clienteEjemplo.setId(1);
        clienteEjemplo.setNombre("Ana");
        clienteEjemplo.setApellido("Soto");
        clienteEjemplo.setCorreo("ana.soto@correo.com");
        clienteEjemplo.setTelefono("+56912345678");
        clienteEjemplo.setRol("CLIENTE");
    }

    @Test
    @DisplayName("obtenerClientes() debe retornar todos los clientes registrados")
    void obtenerClientes_debeRetornarListado() {
        when(repository.findAll()).thenReturn(List.of(clienteEjemplo));

        List<Cliente> resultado = service.obtenerClientes();

        assertEquals(1, resultado.size());
        assertEquals("Ana", resultado.get(0).getNombre());
    }

    @Test
    @DisplayName("buscarPorId() debe retornar el cliente cuando existe")
    void buscarPorId_cuandoExiste_debeRetornarCliente() {
        when(repository.findById(1)).thenReturn(Optional.of(clienteEjemplo));

        Cliente resultado = service.buscarPorId(1);

        assertNotNull(resultado);
        assertEquals("ana.soto@correo.com", resultado.getCorreo());
    }

    @Test
    @DisplayName("buscarPorId() debe retornar null cuando el cliente no existe")
    void buscarPorId_cuandoNoExiste_debeRetornarNull() {
        when(repository.findById(50)).thenReturn(Optional.empty());

        Cliente resultado = service.buscarPorId(50);

        assertNull(resultado);
    }

    @Test
    @DisplayName("guardar() debe persistir el cliente recibido")
    void guardar_debePersistirCliente() {
        when(repository.save(any(Cliente.class))).thenReturn(clienteEjemplo);

        Cliente resultado = service.guardar(clienteEjemplo);

        assertEquals("Soto", resultado.getApellido());
        verify(repository).save(clienteEjemplo);
    }

    @Test
    @DisplayName("eliminar() debe retornar false si el cliente no existe, sin llamar a deleteById")
    void eliminar_cuandoNoExiste_debeRetornarFalse() {
        when(repository.findById(50)).thenReturn(Optional.empty());

        boolean resultado = service.eliminar(50);

        assertFalse(resultado);
        verify(repository, never()).deleteById(anyInt());
    }
}
