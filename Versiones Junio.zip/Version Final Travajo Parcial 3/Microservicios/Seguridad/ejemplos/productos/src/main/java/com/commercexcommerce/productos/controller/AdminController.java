package com.commercexcommerce.productos.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/admin")
@Tag(name = "Administrador", description = "Registro dado con admin")
public class AdminController {

    @GetMapping("/test")
    @Operation(summary = "Entrada con admin", description = "Se usa registro exitoso con permisos de administrador")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Se registro con exito"),
        @ApiResponse(responseCode = "404", description = "No encontrado")})
    public String admin() {
        return "Acceso solo ADMIN";
    }
}