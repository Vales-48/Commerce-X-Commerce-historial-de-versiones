package com.commercexcommerce.productos.controller;

import com.commercexcommerce.productos.model.producto;
import com.commercexcommerce.productos.service.service;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/productos")
@Tag(name = "Productos", description = "Operaciones relacionadas con los productos")
public class controller {

    @Autowired
    private service service;

    @GetMapping
    public List<producto> obtenerProductos() {
        return service.obtenerProductos();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar Productos", description = "Buscara cada producto de nuestro catalogo")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Producto encontrado"),
        @ApiResponse(responseCode = "404", description = "Producto no encontrado")})
    public producto buscarPorId(@PathVariable int id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    @Operation(summary = "Crear Producto")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Producto creado"),
        @ApiResponse(responseCode = "400", description = "Datos invalidos")})
    public producto guardar(@RequestBody producto producto) {
        return service.guardar(producto);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar Productos")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Producto actualizado de forma exitosa"),
        @ApiResponse(responseCode = "400", description = "Producto no ha podido ser actualizado")})
    public producto actualizar(@PathVariable int id, @RequestBody producto producto) {
        return service.actualizar(id, producto);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar Producto")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Producto Borrado exitosamente"),
        @ApiResponse(responseCode = "400", description = "Producto no encontrado")})
    public boolean eliminar(@PathVariable int id) {
        return service.eliminar(id);
    }
    
}
