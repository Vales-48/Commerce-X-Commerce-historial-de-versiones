CREATE TABLE IF NOT EXISTS resultados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    producto_id INT NOT NULL,
    accion VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TRIGGER trg_resultado_producto_insert
AFTER INSERT ON productos
FOR EACH ROW
INSERT INTO resultados (producto_id, accion, descripcion)
VALUES (
    NEW.id,
    'INSERT',
    CONCAT('el producto se registro con exito~: ', NEW.nombre, ' con stock: ', NEW.stock)
);