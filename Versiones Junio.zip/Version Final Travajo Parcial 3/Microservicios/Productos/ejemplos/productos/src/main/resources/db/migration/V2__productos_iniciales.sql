INSERT INTO productos (nombre, categoria, precio, codigo, stock)
VALUES
('Mouse Gamer', 'Tecnologia', 12990, 'PROD001', 15),
('Teclado Mecanico', 'Tecnologia', 24990, 'PROD002', 10);