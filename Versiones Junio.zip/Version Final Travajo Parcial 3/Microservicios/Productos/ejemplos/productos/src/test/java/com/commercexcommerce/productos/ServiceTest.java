package com.commercexcommerce.productos.service;

import com.commercexcommerce.productos.model.producto;
import com.commercexcommerce.productos.repository.repository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Pruebas unitarias del microservicio de Productos.
 *
 * No se usa @SpringBootTest (eso levantaría todo el contexto de Spring,
 * conexión a BD, etc). Para una prueba UNITARIA solo se prueba la clase
 * "service" de forma aislada, simulando ("mockeando") su única dependencia:
 * el repository. Por eso es una prueba rápida (milisegundos) y no necesita
 * MySQL/Laragon corriendo.
 */
@ExtendWith(MockitoExtension.class) // Habilita las anotaciones @Mock y @InjectMocks
class ServiceTest {

    @Mock // Mockito crea un repository "falso": no toca la base de datos real
    private repository repository;

    @InjectMocks // Mockito inyecta el repository falso dentro de esta instancia real de service
    private service service;

    private producto productoEjemplo;

    @BeforeEach
    void setUp() {
        // Dato de prueba reutilizable en varios tests
        productoEjemplo = new producto();
        productoEjemplo.setId(1);
        productoEjemplo.setNombre("Mouse Gamer");
        productoEjemplo.setCategoria("Perifericos");
        productoEjemplo.setPrecio(15990.0);
        productoEjemplo.setCodigo("PER-001");
        productoEjemplo.setStock(20);
    }

    @Test
    @DisplayName("obtenerProductos() debe retornar la lista completa que entrega el repository")
    void obtenerProductos_debeRetornarListaDeProductos() {
        // Given: el repository (falso) responderá con esta lista cuando se le llame findAll()
        List<producto> listaEsperada = List.of(productoEjemplo);
        when(repository.findAll()).thenReturn(listaEsperada);

        // When: se ejecuta el metodo real del service
        List<producto> resultado = service.obtenerProductos();

        // Then: se valida el resultado y que el repository fue realmente invocado
        assertEquals(1, resultado.size());
        assertEquals("Mouse Gamer", resultado.get(0).getNombre());
        verify(repository, times(1)).findAll();
    }

    @Test
    @DisplayName("buscarPorId() debe retornar el producto cuando el id existe")
    void buscarPorId_cuandoExiste_debeRetornarProducto() {
        // Given
        when(repository.findById(1)).thenReturn(Optional.of(productoEjemplo));

        // When
        producto resultado = service.buscarPorId(1);

        // Then
        assertNotNull(resultado);
        assertEquals("PER-001", resultado.getCodigo());
    }

    @Test
    @DisplayName("buscarPorId() debe retornar null cuando el id NO existe (regla de negocio actual)")
    void buscarPorId_cuandoNoExiste_debeRetornarNull() {
        // Given
        when(repository.findById(99)).thenReturn(Optional.empty());

        // When
        producto resultado = service.buscarPorId(99);

        // Then
        assertNull(resultado);
    }

    @Test
    @DisplayName("guardar() debe delegar la persistencia en el repository y retornar el producto guardado")
    void guardar_debePersistirProducto() {
        // Given
        when(repository.save(any(producto.class))).thenReturn(productoEjemplo);

        // When
        producto resultado = service.guardar(productoEjemplo);

        // Then
        assertNotNull(resultado);
        assertEquals("Mouse Gamer", resultado.getNombre());
        verify(repository).save(productoEjemplo);
    }

    @Test
    @DisplayName("actualizar() debe sobreescribir los campos cuando el producto existe")
    void actualizar_cuandoExiste_debeActualizarDatos() {
        // Given
        producto datosNuevos = new producto();
        datosNuevos.setNombre("Mouse Gamer RGB");
        datosNuevos.setCategoria("Perifericos");
        datosNuevos.setPrecio(19990.0);
        datosNuevos.setStock(15);

        when(repository.findById(1)).thenReturn(Optional.of(productoEjemplo));
        when(repository.save(any(producto.class))).thenReturn(productoEjemplo);

        // When
        producto resultado = service.actualizar(1, datosNuevos);

        // Then
        assertEquals("Mouse Gamer RGB", resultado.getNombre());
        assertEquals(19990.0, resultado.getPrecio());
        verify(repository).save(productoEjemplo);
    }

    @Test
    @DisplayName("actualizar() debe retornar null y NO debe llamar a save() si el producto no existe")
    void actualizar_cuandoNoExiste_debeRetornarNullYNoGuardar() {
        // Given
        when(repository.findById(99)).thenReturn(Optional.empty());

        // When
        producto resultado = service.actualizar(99, productoEjemplo);

        // Then
        assertNull(resultado);
        verify(repository, never()).save(any()); // clave: nunca debe intentar guardar algo que no existe
    }

    @Test
    @DisplayName("eliminar() debe retornar true y eliminar cuando el producto existe")
    void eliminar_cuandoExiste_debeRetornarTrue() {
        // Given
        when(repository.findById(1)).thenReturn(Optional.of(productoEjemplo));

        // When
        boolean resultado = service.eliminar(1);

        // Then
        assertTrue(resultado);
        verify(repository).deleteById(1);
    }

    @Test
    @DisplayName("eliminar() debe retornar false y NO debe llamar a deleteById() si no existe")
    void eliminar_cuandoNoExiste_debeRetornarFalse() {
        // Given
        when(repository.findById(99)).thenReturn(Optional.empty());

        // When
        boolean resultado = service.eliminar(99);

        // Then
        assertFalse(resultado);
        verify(repository, never()).deleteById(anyInt());
    }
}
