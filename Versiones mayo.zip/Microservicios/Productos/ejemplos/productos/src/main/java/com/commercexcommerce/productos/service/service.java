package com.commercexcommerce.productos.service;


import com.commercexcommerce.productos.model.producto;
import com.commercexcommerce.productos.repository.repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class service {

    @Autowired
    private repository repository;

    public List<producto> obtenerProductos() {
        return repository.findAll();
    }

    public producto buscarPorId(int id) {
        return repository.findById(id).orElse(null);
    }

    public producto guardar(producto producto) {
        return repository.save(producto);
    }

    public producto actualizar(int id, producto producto) {
        producto existente = repository.findById(id).orElse(null);

        if (existente != null) {
            existente.setNombre(producto.getNombre());
            existente.setCategoria(producto.getCategoria());
            existente.setPrecio(producto.getPrecio());
            existente.setStock(producto.getStock());
            return repository.save(existente);
        }

        return null;
    }

    public boolean eliminar(int id) {
        producto existente = repository.findById(id).orElse(null);

        if (existente != null) {
            repository.deleteById(id);
            return true;
        }

        return false;
    }
}