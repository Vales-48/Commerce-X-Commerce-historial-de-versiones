package com.commercexcommerce.productos.controller;

import com.commercexcommerce.productos.model.producto;
import com.commercexcommerce.productos.service.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/productos")
public class controller {

    @Autowired
    private service service;

    @GetMapping
    public List<producto> obtenerProductos() {
        return service.obtenerProductos();
    }

    @GetMapping("/{id}")
    public producto buscarPorId(@PathVariable int id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public producto guardar(@RequestBody producto producto) {
        return service.guardar(producto);
    }

    @PutMapping("/{id}")
    public producto actualizar(@PathVariable int id, @RequestBody producto producto) {
        return service.actualizar(id, producto);
    }

    @DeleteMapping("/{id}")
    public boolean eliminar(@PathVariable int id) {
        return service.eliminar(id);
    }
    
}
