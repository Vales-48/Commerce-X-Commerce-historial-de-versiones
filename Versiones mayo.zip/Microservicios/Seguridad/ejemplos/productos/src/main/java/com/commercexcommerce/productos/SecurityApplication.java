package com.commercexcommerce.productos;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.commercexcommerce.productos.model.Role;
import com.commercexcommerce.productos.model.User;
import com.commercexcommerce.productos.repository.UserRepository;

@SpringBootApplication
public class SecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityApplication.class, args);}
	@Bean
	CommandLineRunner init(UserRepository repo, PasswordEncoder encoder) {
    	return args -> {
    	    if (repo.findByUsername("The-Admin").isEmpty()) {
        	    User user = new User();
           		user.setUsername("The-Admin");
            	user.setPassword(encoder.encode("OSU"));
            	user.setRole(Role.ROLE_ADMIN);
            	repo.save(user);
			}
		};
	}
}