package com.commercexcommerce.productos.model;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
