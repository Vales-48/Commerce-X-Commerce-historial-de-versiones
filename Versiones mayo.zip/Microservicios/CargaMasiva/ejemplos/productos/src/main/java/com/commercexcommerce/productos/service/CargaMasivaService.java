package com.commercexcommerce.productos.service;


import com.commercexcommerce.productos.model.producto;
import com.commercexcommerce.productos.dto.ProductoDTO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class CargaMasivaService {
    @PersistenceContext
    private EntityManager entityManager;
    @Transactional
    public void procesarCarga(List<ProductoDTO> listaDto) {
        int batchSize = 50;

        for (int i = 0; i < listaDto.size(); i++) {
            ProductoDTO dto = listaDto.get(i);

            producto producto = new producto();
            producto.setCodigo(dto.getCodigo());
            producto.setNombre(dto.getNombre());
            producto.setCategoria(dto.getCategoria());
            producto.setPrecio(dto.getPrecio());
            producto.setStock(dto.getStock());

            entityManager.persist(producto);

            if (i > 0 && i % batchSize == 0) {
                entityManager.flush();
                entityManager.clear();
            }
        }
    }
}