package com.commercexcommerce.productos.controller;

import com.commercexcommerce.productos.dto.ProductoDTO;
import com.commercexcommerce.productos.service.CargaMasivaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/productos")
public class controller {
    @Autowired
    private CargaMasivaService service;
    @PostMapping("/masivo")
    public ResponseEntity<?> cargar(@RequestBody List<ProductoDTO> productos) {
        try {
            if (productos == null || productos.isEmpty()) {
                return ResponseEntity.badRequest().body("La lista está vacía");
            }
            long inicio = System.currentTimeMillis();
            service.procesarCarga(productos);
            long fin = System.currentTimeMillis();
            return ResponseEntity.ok("Éxito: " + productos.size() + " procesados en " + (fin - inicio) + "ms");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error en la carga: " + e.getMessage());
        }
    }
}