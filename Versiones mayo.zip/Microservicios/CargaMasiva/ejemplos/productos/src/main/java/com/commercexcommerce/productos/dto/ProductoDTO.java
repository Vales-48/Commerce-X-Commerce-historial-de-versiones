package com.commercexcommerce.productos.dto;
import lombok.Data;

@Data
public class ProductoDTO {
    private String codigo;
    private String nombre;
    private String categoria;
    private Double precio;
    private Integer stock;
}