SELECT * FROM productos;
