package com.commercexcommerce.productos.service;

import com.commercexcommerce.productos.model.Cliente;
import com.commercexcommerce.productos.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class service {

    @Autowired
    private repository repository;

    public List<Cliente> obtenerClientes() {
        return repository.findAll();
    }

    public Cliente buscarPorId(int id) {
        return repository.findById(id).orElse(null);
    }

    public Cliente guardar(Cliente cliente) {
        return repository.save(cliente);
    }

    public Cliente actualizar(int id, Cliente cliente) {
        Cliente existente = repository.findById(id).orElse(null);

        if (existente != null) {
            existente.setNombre(cliente.getNombre());
            existente.setApellido(cliente.getApellido());
            existente.setCorreo(cliente.getCorreo());
            existente.setTelefono(cliente.getTelefono());
            existente.setRol(cliente.getRol());
            return repository.save(existente);
        }

        return null;
    }

    public boolean eliminar(int id) {
        Cliente existente = repository.findById(id).orElse(null);

        if (existente != null) {
            repository.deleteById(id);
            return true;
        }

        return false;
    }
}