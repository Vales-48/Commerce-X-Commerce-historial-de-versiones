package com.commercexcommerce.productos.repository;

import com.commercexcommerce.productos.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface repository extends JpaRepository<Cliente, Integer> {
}