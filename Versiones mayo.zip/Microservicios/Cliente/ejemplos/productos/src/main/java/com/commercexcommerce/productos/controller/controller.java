package com.commercexcommerce.productos.controller;

import com.commercexcommerce.productos.clientes.ProductoCliente;
import com.commercexcommerce.productos.dto.ProductoDTO;
import com.commercexcommerce.productos.model.Cliente;
import com.commercexcommerce.productos.service.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/v1/clientes")
public class controller {

    @Autowired
    private service service;

    @Autowired
    private ProductoCliente productoCliente;

    @GetMapping
    public List<Cliente> obtenerClientes() {
        return service.obtenerClientes();
    }

    @GetMapping("/{id}")
    public Cliente buscarPorId(@PathVariable int id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public Cliente guardar(@RequestBody Cliente cliente) {
        return service.guardar(cliente);
    }

    @PutMapping("/{id}")
    public Cliente actualizar(@PathVariable int id, @RequestBody Cliente cliente) {
        return service.actualizar(id, cliente);
    }

    @DeleteMapping("/{id}")
    public boolean eliminar(@PathVariable int id) {
        return service.eliminar(id);
    }

    @GetMapping("/producto/{idProducto}")
    public ProductoDTO consultarProductoDesdeCliente(@PathVariable int idProducto) {
        return productoCliente.buscarProductoPorId(idProducto);
    }
}