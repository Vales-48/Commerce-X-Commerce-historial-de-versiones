package com.commercexcommerce.productos.clientes;

import com.commercexcommerce.productos.dto.ProductoDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "productos-service", url = "http://localhost:8082")
public interface ProductoCliente {

    @GetMapping("/api/v1/productos/{id}")
    ProductoDTO buscarProductoPorId(@PathVariable("id") int id);
}