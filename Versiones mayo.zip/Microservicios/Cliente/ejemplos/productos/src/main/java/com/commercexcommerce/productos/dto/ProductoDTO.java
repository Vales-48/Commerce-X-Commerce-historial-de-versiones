package com.commercexcommerce.productos.dto;

import lombok.Data;

@Data
public class ProductoDTO {
    private int id;
    private String nombre;
    private String categoria;
    private double precio;
    private String codigo;
    private int stock;
}